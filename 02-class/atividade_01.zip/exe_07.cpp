#include <iostream>

using namespace std;

int main(){
  int num1;
  char letter;
  float num2;
  double num3;

  cout << "Type a interger number: ";
  cin >> num1;

  cout << "Type a letter: ";
  cin >> letter;

  cout << "Type a float number: ";
  cin >> num2;

  cout << "Type a double number: ";
  cin >> num3;

  cout << "The values are: " << num1 << ", " << letter << ", " << num2 << ", " << num3 << endl;
}
