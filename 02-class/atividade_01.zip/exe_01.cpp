int main () {
  int interger = 10;
  char letter = 'a';
  float decimal = 2.0;

  int int_vector[] = {1, 2, 3, 4, 5};
  char char_vector[] = {'a', 'b', 'c', 'd', 'e'};
  float float_vector[] = {1.0, 2.0, 3.0, 4.0, 5.0};


  return 0;
}
